// ─── App.js — Client entry point ─────────────────────────────────────────────
window.App = (() => {
  const socket = io();

  let myId   = null;
  let myName = null;
  let currentRoom = null;
  let currentGameUI = null;

  // ── Screen helper ──────────────────────────────────────────────────────────
  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const el = document.getElementById(id);
    if (el) el.classList.add('active');
  }
  // Expose so the gate script can call it (it already sets window.showScreen)
  window.showScreen = showScreen;

  // ── Game registry ──────────────────────────────────────────────────────────
  const GAMES = [
    { id: 'wordle',      name: 'Wordle',           icon: '🟩', players: '2–6', ui: () => window.WordleUI },
    { id: 'connections', name: 'Connections',       icon: '🔗', players: '2–6', ui: () => window.ConnectionsUI },
    { id: 'contexto',    name: 'Contexto',          icon: '🧠', players: '2–4', ui: () => window.ContextoUI },
    { id: 'connect4',    name: 'Connect 4',         icon: '🔴', players: '2',   ui: () => window.Connect4UI },
    { id: 'uno',         name: 'UNO',               icon: '🃏', players: '2–8', ui: () => window.UnoUI },
    { id: 'wyr',         name: 'Would You Rather',  icon: '🤔', players: '2–8', ui: () => window.WouldYouRatherUI },
    { id: '2truths',     name: '2 Truths 1 Lie',    icon: '🤥', players: '2–8', ui: () => window.TwoTruthsUI },
    { id: 'nhie',        name: 'Never Have I Ever', icon: '🙅', players: '2–8', ui: () => window.NeverHaveIEverUI },
  ];

  let selectedGame = GAMES[0].id;

  // ── Login ──────────────────────────────────────────────────────────────────
  const loginBtn   = document.getElementById('loginBtn');
  const nameInput  = document.getElementById('usernameInput');
  const loginError = document.getElementById('loginError');

  function doLogin() {
    const name = (nameInput.value || '').trim();
    if (!name) { loginError.textContent = 'Please enter a name.'; return; }
    myName = name;
    loginError.textContent = '';
    socket.emit('setName', { name });
  }

  loginBtn.addEventListener('click', doLogin);
  nameInput.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });

  socket.on('nameAccepted', ({ id }) => {
    myId = id;
    document.getElementById('userBadge').textContent  = myName;
    document.getElementById('userBadge2').textContent = myName;
    buildGameGrid();
    getLobbyList();
    showScreen('lobby');
  });

  socket.on('nameError', ({ message }) => {
    loginError.textContent = message || 'Name not accepted.';
  });

  // ── Lobby ──────────────────────────────────────────────────────────────────
  function buildGameGrid() {
    const grid = document.getElementById('gameGrid');
    if (!grid) return;
    grid.innerHTML = '';
    GAMES.forEach(g => {
      const card = document.createElement('div');
      card.className = 'game-card' + (g.id === selectedGame ? ' selected' : '');
      card.innerHTML = `<span class="game-card-icon">${g.icon}</span>
        <div class="game-card-name">${g.name}</div>
        <div class="game-card-players">${g.players} players</div>`;
      card.addEventListener('click', () => {
        selectedGame = g.id;
        grid.querySelectorAll('.game-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
      });
      grid.appendChild(card);
    });
  }

  function getLobbyList() {
    socket.emit('getLobbyList');
  }

  socket.on('lobbyList', ({ rooms }) => {
    const el = document.getElementById('lobbyList');
    if (!el) return;
    if (!rooms || rooms.length === 0) {
      el.innerHTML = '<div class="empty-rooms">No open rooms yet.</div>';
      return;
    }
    el.innerHTML = '';
    rooms.forEach(r => {
      const item = document.createElement('div');
      item.className = 'room-item';
      item.innerHTML = `<div>
          <div class="room-item-name">${r.name || r.gameId}</div>
          <div class="room-item-code">${r.code}</div>
        </div>
        <div class="room-item-count">${r.playerCount} in room</div>`;
      item.addEventListener('click', () => socket.emit('joinRoom', { code: r.code }));
      el.appendChild(item);
    });
  });

  const createBtn = document.getElementById('createBtn');
  if (createBtn) {
    createBtn.addEventListener('click', () => {
      socket.emit('createRoom', { gameId: selectedGame });
    });
  }

  // ── Room ───────────────────────────────────────────────────────────────────
  socket.on('roomJoined', ({ room }) => {
    currentRoom = room;
    updateRoomUI(room);
    showScreen('gameRoom');
  });

  socket.on('roomUpdated', ({ room }) => {
    currentRoom = room;
    updateRoomUI(room);
  });

  function updateRoomUI(room) {
    const game = GAMES.find(g => g.id === room.gameId) || { name: room.gameId, icon: '🎮' };
    const roomInfo = document.getElementById('roomInfo');
    if (roomInfo) roomInfo.textContent = `${game.icon} ${game.name} · ${room.code}`;

    const lobbyCode = document.getElementById('lobbyCode');
    if (lobbyCode) lobbyCode.textContent = room.code;

    const playerList = document.getElementById('playerList');
    if (playerList) {
      playerList.innerHTML = '';
      (room.players || []).forEach(p => {
        const li = document.createElement('li');
        li.className = 'player-item' + (p.id === room.hostId ? ' host' : '');
        li.innerHTML = `<div class="player-dot"></div>
          <span class="player-name">${p.name}${p.id === room.hostId ? ' ♛' : ''}</span>`;
        playerList.appendChild(li);
      });
    }

    const startBtn = document.getElementById('startBtn');
    if (startBtn) {
      const isHost = room.hostId === myId;
      startBtn.classList.toggle('hidden', !isHost || room.gameActive);
      startBtn.onclick = () => socket.emit('startGame', {});
    }

    const waitingMsg    = document.getElementById('waitingMsg');
    const gameContainer = document.getElementById('gameContainer');
    if (!room.gameActive) {
      waitingMsg?.classList.remove('hidden');
      gameContainer?.classList.add('hidden');
    }
  }

  socket.on('roomError', ({ message }) => {
    alert(message || 'Room error.');
  });

  // ── Game ───────────────────────────────────────────────────────────────────
  socket.on('gameStarted', ({ gameId, state }) => {
    const waitingMsg    = document.getElementById('waitingMsg');
    const gameContainer = document.getElementById('gameContainer');
    waitingMsg?.classList.add('hidden');
    gameContainer?.classList.remove('hidden');
    gameContainer.innerHTML = '';

    const gameInfo = GAMES.find(g => g.id === gameId);
    const UIFactory = gameInfo?.ui?.();
    if (UIFactory) {
      currentGameUI = UIFactory.init(gameContainer, socket, myId);
      if (state && currentGameUI?.onState) currentGameUI.onState(state);
    } else {
      gameContainer.innerHTML = `<div class="waiting-msg"><div class="waiting-icon">◈</div><h2>${gameId}</h2><p>Game started!</p></div>`;
    }
  });

  socket.on('gameState', ({ state }) => {
    if (currentGameUI?.onState) currentGameUI.onState(state);
  });

  socket.on('gameFinished', ({ result }) => {
    if (currentGameUI?.onFinish) currentGameUI.onFinish(result);
  });

  socket.on('gameError', ({ message }) => {
    if (currentGameUI?.onError) currentGameUI.onError(message);
  });

  // ── Chat ───────────────────────────────────────────────────────────────────
  const chatSendBtn = document.getElementById('chatSendBtn');
  const chatInput   = document.getElementById('chatInput');
  const chatLog     = document.getElementById('chatLog');

  function sendChat() {
    const msg = (chatInput.value || '').trim();
    if (!msg) return;
    socket.emit('chatMessage', { message: msg });
    chatInput.value = '';
  }

  chatSendBtn?.addEventListener('click', sendChat);
  chatInput?.addEventListener('keydown', e => { if (e.key === 'Enter') sendChat(); });

  socket.on('chatMessage', ({ name, message, system }) => {
    if (!chatLog) return;
    const div = document.createElement('div');
    div.className = 'chat-msg' + (system ? ' sys' : '');
    div.innerHTML = system
      ? message
      : `<span class="chat-from">${name}:</span> ${message}`;
    chatLog.appendChild(div);
    chatLog.scrollTop = chatLog.scrollHeight;
  });

  // ── Leave ──────────────────────────────────────────────────────────────────
  function leaveLobby() {
    socket.emit('leaveRoom', {});
    currentRoom    = null;
    currentGameUI  = null;
    getLobbyList();
    showScreen('lobby');
  }

  socket.on('disconnect', () => {
    loginError.textContent = 'Disconnected. Refresh to reconnect.';
    showScreen('login');
  });

  return { getLobbyList, leaveLobby };
})();
