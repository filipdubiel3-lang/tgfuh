// ─── server.js ────────────────────────────────────────────────────────────────
const express   = require('express');
const http      = require('http');
const { Server } = require('socket.io');
const path      = require('path');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

// ─── State ────────────────────────────────────────────────────────────────────
const players = new Map(); // socketId → { id, name, roomCode }
const rooms   = new Map(); // code    → Room

function genCode() {
  return Math.random().toString(36).slice(2, 6).toUpperCase();
}

function getRoomFor(socketId) {
  const p = players.get(socketId);
  if (!p || !p.roomCode) return null;
  return rooms.get(p.roomCode) || null;
}

// ─── Room ─────────────────────────────────────────────────────────────────────
class Room {
  constructor(hostId, gameId) {
    this.code       = genCode();
    this.gameId     = gameId;
    this.hostId     = hostId;
    this.players    = []; // { id, name }
    this.gameActive = false;
    this.gameState  = null;
    this.gameEngine = null;
  }

  serialize() {
    return {
      code:       this.code,
      gameId:     this.gameId,
      hostId:     this.hostId,
      players:    this.players,
      gameActive: this.gameActive,
    };
  }

  broadcast(event, data) {
    io.to(this.code).emit(event, data);
  }

  addPlayer(player) {
    if (!this.players.find(p => p.id === player.id)) {
      this.players.push({ id: player.id, name: player.name });
    }
  }

  removePlayer(id) {
    this.players = this.players.filter(p => p.id !== id);
    if (this.players.length > 0 && this.hostId === id) {
      this.hostId = this.players[0].id;
    }
  }
}

// ─── Game Engines ─────────────────────────────────────────────────────────────

// ── Wordle ────────────────────────────────────────────────────────────────────
const WORDLE_WORDS = [
  'CRANE','SLATE','ADIEU','AUDIO','RAISE','ARISE','STARE','SNARE','CRATE','TRACE',
  'LEAST','STALE','TALES','LEATS','TARES','TEARS','UREAS','RATES','ASTER','EARLS',
  'LATER','ALTER','ALERT','RATEL','ARLES','LARES','LASER','LEARS','REALS','REALM',
  'FLAME','FRAME','PLANE','PLACE','GRACE','BRACE','GRADE','BRAKE','DRAPE','GRAPE',
  'BRAVE','SHAVE','SLAVE','CRAVE','GRAZE','GLAZE','BLAZE','PHASE','CHASE','SHAKE',
  'SHAPE','SHARE','SHORE','SCORE','STORE','SNORE','STOKE','SMOKE','SPOKE','WOKE',
  'BLOKE','CLOKE','EVOKE','QUOTE','WROTE','GROVE','PROVE','DROVE','ABOVE','TROVE',
  'LOVER','COVER','HOVER','MOVER','ROVER','TOWER','POWER','LOWER','BOWER','SOWER',
  'BOXER','FIXER','MIXER','LIFER','RIDER','HIDER','VIPER','TIGER','LIVER','DIVER',
  'GIVEN','RISEN','TOKEN','DOZEN','FROZEN','CHOSEN','WOKEN','SPOKEN','BROKEN','STOLEN',
].map(w => w.toUpperCase()).filter(w => w.length === 5);

class WordleEngine {
  constructor(players) {
    this.answer  = WORDLE_WORDS[Math.floor(Math.random() * WORDLE_WORDS.length)];
    this.boards  = {}; // id → { guesses:[], results:[], solved, attempts }
    this.finished = false;
    players.forEach(p => {
      this.boards[p.id] = { guesses: [], results: [], solved: false, attempts: 0 };
    });
  }

  stateFor(id) {
    return {
      board:    this.boards[id],
      progress: Object.fromEntries(Object.entries(this.boards).map(([pid, b]) => [pid, { solved: b.solved, attempts: b.attempts }])),
      finished: this.finished,
    };
  }

  action(playerId, data) {
    if (this.finished) return { error: 'Game over.' };
    const board = this.boards[playerId];
    if (!board) return { error: 'Not in game.' };
    if (board.solved) return { error: 'Already solved!' };
    if (board.attempts >= 6) return { error: 'No more guesses.' };
    if (data.type !== 'guess') return { error: 'Unknown action.' };

    const word = (data.word || '').toUpperCase();
    if (word.length !== 5) return { error: 'Must be 5 letters.' };
    if (!/^[A-Z]{5}$/.test(word)) return { error: 'Letters only.' };

    const result = this._score(word);
    board.guesses.push(word);
    board.results.push(result);
    board.attempts++;
    if (word === this.answer) board.solved = true;

    const allDone = Object.values(this.boards).every(b => b.solved || b.attempts >= 6);
    let finishResult = null;
    if (allDone) {
      this.finished = true;
      const winner = Object.entries(this.boards).find(([, b]) => b.solved)?.[0] || null;
      finishResult = { winner, answer: this.answer };
    } else if (board.attempts >= 6 && !board.solved) {
      // This player is done but others are not
      if (board.solved === false) {
        // Check if only this player is left
        const others = Object.entries(this.boards).filter(([id]) => id !== playerId);
        if (others.every(([, b]) => b.solved || b.attempts >= 6)) {
          this.finished = true;
          const winner = Object.entries(this.boards).find(([, b]) => b.solved)?.[0] || null;
          finishResult = { winner, answer: this.answer };
        }
      }
    }

    return { ok: true, finishResult };
  }

  _score(guess) {
    const answer = this.answer.split('');
    const result = Array(5).fill('absent');
    const used   = Array(5).fill(false);

    // Correct pass
    for (let i = 0; i < 5; i++) {
      if (guess[i] === answer[i]) { result[i] = 'correct'; used[i] = true; }
    }
    // Present pass
    for (let i = 0; i < 5; i++) {
      if (result[i] === 'correct') continue;
      const idx = answer.findIndex((l, j) => l === guess[i] && !used[j]);
      if (idx !== -1) { result[i] = 'present'; used[idx] = true; }
    }
    return result;
  }
}

// ── Connections ────────────────────────────────────────────────────────────────
const CONNECTION_SETS = [
  {
    groups: [
      { name: 'Things that fly',   color: 'yellow', words: ['EAGLE','PLANE','KITE','BALLOON'] },
      { name: 'Types of music',    color: 'green',  words: ['JAZZ','ROCK','BLUES','POP'] },
      { name: 'Card games',        color: 'blue',   words: ['POKER','UNO','SNAP','WAR'] },
      { name: '___ board',         color: 'purple', words: ['SKATE','CARD','SURF','DART'] },
    ],
  },
  {
    groups: [
      { name: 'Fruit',             color: 'yellow', words: ['MANGO','PEACH','GRAPE','PLUM'] },
      { name: 'Ocean creatures',   color: 'green',  words: ['WHALE','SQUID','SHARK','CRAB'] },
      { name: 'Dog breeds',        color: 'blue',   words: ['HUSKY','BOXER','POODLE','SHIH'] },
      { name: '___ fish',          color: 'purple', words: ['SWORD','CAT','BLOW','STAR'] },
    ],
  },
  {
    groups: [
      { name: 'Colors',            color: 'yellow', words: ['SCARLET','JADE','IVORY','AMBER'] },
      { name: 'Board games',       color: 'green',  words: ['CHESS','GO','RISK','CLUE'] },
      { name: 'Types of pasta',    color: 'blue',   words: ['PENNE','FUSILLI','ORZO','ZITI'] },
      { name: '___ stone',         color: 'purple', words: ['LIME','SAND','BROWN','CORNER'] },
    ],
  },
];

class ConnectionsEngine {
  constructor(players) {
    const set = CONNECTION_SETS[Math.floor(Math.random() * CONNECTION_SETS.length)];
    this.groups  = set.groups;
    this.allWords = this.groups.flatMap(g => g.words).sort(() => Math.random() - 0.5);
    this.finished = false;
    this.progress = {};
    this.winner   = null;

    players.forEach(p => {
      this.progress[p.id] = {
        words:      [...this.allWords],
        solved:     [],
        mistakes:   0,
        maxMistakes: 4,
      };
    });
  }

  stateFor(id) {
    const p = this.progress[id];
    return {
      words:      p.words,
      solved:     p.solved,
      mistakes:   p.mistakes,
      maxMistakes: p.maxMistakes,
      progress:   Object.fromEntries(Object.entries(this.progress).map(([pid, pp]) => [pid, { solved: pp.solved.length }])),
    };
  }

  action(playerId, data) {
    if (this.finished) return { error: 'Game over.' };
    const p = this.progress[playerId];
    if (!p) return { error: 'Not in game.' };
    if (data.type !== 'guess') return { error: 'Unknown action.' };

    const guess = data.words || [];
    if (guess.length !== 4) return { error: 'Select exactly 4 words.' };

    const matchedGroup = this.groups.find(g =>
      g.words.every(w => guess.includes(w)) && guess.every(w => g.words.includes(w))
      && !p.solved.find(s => s.name === g.name)
    );

    if (matchedGroup) {
      p.solved.push(matchedGroup);
      p.words = p.words.filter(w => !matchedGroup.words.includes(w));
      if (p.solved.length === 4) {
        if (!this.winner) {
          this.winner = playerId;
          this.finished = true;
          return { ok: true, finishResult: { winner: this.winner } };
        }
      }
      return { ok: true };
    } else {
      p.mistakes++;
      if (p.mistakes >= p.maxMistakes) {
        return { ok: true, error: 'Out of guesses.' };
      }
      return { error: 'Not a valid group.' };
    }
  }
}

// ── Connect 4 ─────────────────────────────────────────────────────────────────
class Connect4Engine {
  constructor(players) {
    this.players = players.slice(0, 2);
    this.board   = Array(6).fill(null).map(() => Array(7).fill(null));
    this.currentIdx = 0;
    this.finished   = false;
    this.colors     = { [this.players[0].id]: 'red', [this.players[1]?.id]: 'yellow' };
  }

  get currentPlayer() { return this.players[this.currentIdx]; }

  stateFor(id) {
    return {
      board:         this.board,
      currentPlayer: this.currentPlayer?.id,
      colors:        this.colors,
      finished:      this.finished,
    };
  }

  action(playerId, data) {
    if (this.finished) return { error: 'Game over.' };
    if (this.currentPlayer?.id !== playerId) return { error: "Not your turn." };
    if (data.type !== 'drop') return { error: 'Unknown action.' };

    const col = data.col;
    if (col < 0 || col > 6) return { error: 'Invalid column.' };

    let row = -1;
    for (let r = 5; r >= 0; r--) {
      if (!this.board[r][col]) { row = r; break; }
    }
    if (row === -1) return { error: 'Column full.' };

    const color = this.colors[playerId];
    this.board[row][col] = color;

    if (this._checkWin(row, col, color)) {
      this.finished = true;
      return { ok: true, finishResult: { winner: playerId } };
    }
    if (this.board[0].every(c => c)) {
      this.finished = true;
      return { ok: true, finishResult: { winner: null } };
    }

    this.currentIdx = 1 - this.currentIdx;
    return { ok: true };
  }

  _checkWin(row, col, color) {
    const dirs = [[0,1],[1,0],[1,1],[1,-1]];
    for (const [dr, dc] of dirs) {
      let count = 1;
      for (const sign of [1, -1]) {
        let r = row + sign * dr, c = col + sign * dc;
        while (r >= 0 && r < 6 && c >= 0 && c < 7 && this.board[r][c] === color) {
          count++; r += sign * dr; c += sign * dc;
        }
      }
      if (count >= 4) return true;
    }
    return false;
  }
}

// ── UNO ────────────────────────────────────────────────────────────────────────
const UNO_COLORS  = ['red','blue','green','yellow'];
const UNO_VALUES  = ['0','1','2','3','4','5','6','7','8','9','skip','reverse','draw2'];

class UnoEngine {
  constructor(players) {
    this.players      = players;
    this.hands        = {};
    this.drawPile     = [];
    this.discardPile  = [];
    this.currentIdx   = 0;
    this.direction    = 1;
    this.activeColor  = null;
    this.finished     = false;
    this._buildDeck();
    this._deal();
  }

  _buildDeck() {
    const deck = [];
    UNO_COLORS.forEach(c => {
      UNO_VALUES.forEach(v => {
        deck.push({ color: c, value: v });
        if (v !== '0') deck.push({ color: c, value: v });
      });
    });
    for (let i = 0; i < 4; i++) {
      deck.push({ color: 'wild', value: 'wild' });
      deck.push({ color: 'wild', value: 'wild4' });
    }
    this.drawPile = deck.sort(() => Math.random() - 0.5);
  }

  _deal() {
    this.players.forEach(p => {
      this.hands[p.id] = [];
      for (let i = 0; i < 7; i++) this.hands[p.id].push(this.drawPile.pop());
    });
    let top;
    do { top = this.drawPile.pop(); } while (top.color === 'wild');
    this.discardPile.push(top);
    this.activeColor = top.color;
  }

  get currentPlayer() { return this.players[this.currentIdx]; }
  get topCard() { return this.discardPile[this.discardPile.length - 1]; }

  stateFor(id) {
    return {
      top:           this.topCard,
      activeColor:   this.activeColor,
      currentPlayer: this.currentPlayer?.id,
      hand:          this.hands[id] || [],
      handCounts:    Object.fromEntries(Object.entries(this.hands).map(([pid, h]) => [pid, h.length])),
    };
  }

  _advance(steps = 1) {
    this.currentIdx = ((this.currentIdx + this.direction * steps) % this.players.length + this.players.length) % this.players.length;
  }

  action(playerId, data) {
    if (this.finished) return { error: 'Game over.' };
    if (this.currentPlayer?.id !== playerId) return { error: "Not your turn." };

    if (data.type === 'draw') {
      if (this.drawPile.length === 0) {
        const top2 = this.discardPile.pop();
        this.drawPile = this.discardPile.sort(() => Math.random() - 0.5);
        this.discardPile = [top2];
      }
      const card = this.drawPile.pop();
      if (card) this.hands[playerId].push(card);
      this._advance();
      return { ok: true };
    }

    if (data.type === 'play') {
      const hand = this.hands[playerId];
      const card = hand[data.cardIdx];
      if (!card) return { error: 'Invalid card.' };

      const top = this.topCard;
      const isPlayable = card.color === 'wild'
        || card.color === this.activeColor
        || card.value === top.value;
      if (!isPlayable) return { error: 'Cannot play that card.' };

      hand.splice(data.cardIdx, 1);
      this.discardPile.push(card);

      if (card.color === 'wild') {
        this.activeColor = data.chosenColor || 'red';
      } else {
        this.activeColor = card.color;
      }

      if (hand.length === 0) {
        this.finished = true;
        const scores = {};
        this.players.forEach(p => {
          scores[p.id] = this.hands[p.id].reduce((sum, c) => {
            const v = parseInt(c.value) || (c.value === 'skip'||c.value==='reverse'||c.value==='draw2' ? 20 : 50);
            return sum + v;
          }, 0);
        });
        return { ok: true, finishResult: { winner: playerId, scores } };
      }

      if (card.value === 'reverse') this.direction *= -1;
      if (card.value === 'skip') { this._advance(2); return { ok: true }; }
      if (card.value === 'draw2') {
        this._advance();
        const next = this.currentPlayer;
        for (let i = 0; i < 2; i++) {
          if (this.drawPile.length === 0) {
            const t = this.discardPile.pop();
            this.drawPile = this.discardPile.sort(() => Math.random() - 0.5);
            this.discardPile = [t];
          }
          const c = this.drawPile.pop();
          if (c) this.hands[next.id].push(c);
        }
        this._advance();
        return { ok: true };
      }
      if (card.value === 'wild4') {
        this._advance();
        const next = this.currentPlayer;
        for (let i = 0; i < 4; i++) {
          const c = this.drawPile.pop();
          if (c) this.hands[next.id].push(c);
        }
        this._advance();
        return { ok: true };
      }

      this._advance();
      return { ok: true };
    }

    return { error: 'Unknown action.' };
  }
}

// ── Social games (WYR, Truth or Dare, 2 Truths, NHIE) ─────────────────────────
// Simple stateless engines that just pass state through

const TRUTH_PROMPTS = [
  "What's the most embarrassing thing you've done in public?",
  "What's a lie you've told that you regret?",
  "Who was your first crush?",
  "What's your most irrational fear?",
  "What's the weirdest dream you've had?",
  "What's something you've never told anyone?",
  "What's your biggest regret?",
  "Have you ever cheated on a test?",
  "What's the worst gift you've ever received?",
  "What's a habit you have that you're ashamed of?",
];
const DARE_PROMPTS = [
  "Do your best animal impression.",
  "Speak in an accent for the next 2 minutes.",
  "Send a silly selfie to the group.",
  "Tell a joke — if nobody laughs you have to do another dare.",
  "Make up a short poem about the person to your left.",
  "Try to lick your elbow.",
  "Do 10 jumping jacks right now.",
  "Say the alphabet backwards.",
  "Tell everyone your most used emoji and why.",
  "Describe your last dream in detail.",
];
const WYR_QUESTIONS = [
  { optionA: "Always be 10 minutes late", optionB: "Always be 20 minutes early" },
  { optionA: "Have no internet for a month", optionB: "Have no phone for a month" },
  { optionA: "Live without music", optionB: "Live without TV/movies" },
  { optionA: "Only eat sweet food forever", optionB: "Only eat savoury food forever" },
  { optionA: "Be able to fly", optionB: "Be able to be invisible" },
  { optionA: "Have a rewind button for your life", optionB: "Have a pause button for your life" },
  { optionA: "Always speak your mind", optionB: "Always know what others think of you" },
  { optionA: "Be famous but hated", optionB: "Be unknown but loved" },
  { optionA: "Lose all your memories from birth to age 18", optionB: "Lose all your memories from the last 5 years" },
  { optionA: "Never have to sleep", optionB: "Never have to eat" },
];
const NHIE_QUESTIONS = [
  "Never have I ever been to another continent.",
  "Never have I ever pulled an all-nighter.",
  "Never have I ever eaten something I found on the floor.",
  "Never have I ever pretended to be sick to skip something.",
  "Never have I ever laughed so hard I cried.",
  "Never have I ever been in a car accident.",
  "Never have I ever sung karaoke.",
  "Never have I ever gone skinny dipping.",
  "Never have I ever stalked someone on social media for hours.",
  "Never have I ever sent a text to the wrong person.",
  "Never have I ever lied about my age.",
  "Never have I ever binge-watched a whole series in one day.",
];

class TruthOrDareEngine {
  constructor(players) {
    this.players  = players;
    this.scores   = Object.fromEntries(players.map(p => [p.id, 0]));
    this.currentIdx = 0;
    this.phase    = 'pick'; // pick | waiting
    this.prompt   = null;
    this.finished = false;
    this.round    = 0;
    this.maxRounds = players.length * 3;
  }

  get currentPlayer() { return this.players[this.currentIdx]; }

  stateFor(id) {
    return {
      phase:         this.phase,
      currentPlayer: this.currentPlayer,
      prompt:        this.prompt,
      scores:        this.scores,
      players:       this.players,
      isMyTurn:      this.currentPlayer?.id === id,
      round:         this.round,
    };
  }

  action(playerId, data) {
    if (this.finished) return { error: 'Game over.' };
    if (this.phase === 'pick') {
      if (this.currentPlayer?.id !== playerId) return { error: "Not your turn." };
      if (data.type === 'pick') {
        const pool = data.choice === 'truth' ? TRUTH_PROMPTS : DARE_PROMPTS;
        this.prompt = pool[Math.floor(Math.random() * pool.length)];
        this.phase  = 'waiting';
        return { ok: true };
      }
    }
    if (this.phase === 'waiting') {
      if (this.currentPlayer?.id !== playerId) return { error: "Not your turn." };
      if (data.type === 'done') {
        this.scores[playerId] = (this.scores[playerId] || 0) + 1;
        this.round++;
        this.currentIdx = (this.currentIdx + 1) % this.players.length;
        this.phase = 'pick';
        this.prompt = null;
        if (this.round >= this.maxRounds) {
          this.finished = true;
          const winner = Object.entries(this.scores).sort((a,b) => b[1]-a[1])[0][0];
          return { ok: true, finishResult: { winner } };
        }
        return { ok: true };
      }
    }
    return { error: 'Unknown action.' };
  }
}

class WouldYouRatherEngine {
  constructor(players) {
    this.players    = players;
    this.scores     = Object.fromEntries(players.map(p => [p.id, 0]));
    this.questions  = WYR_QUESTIONS.sort(() => Math.random() - 0.5).slice(0, 6);
    this.currentQ   = 0;
    this.votes      = {};
    this.phase      = 'vote';
    this.finished   = false;
    this.submitted  = new Set();
  }

  get question() { return this.questions[this.currentQ]; }

  stateFor(id) {
    return {
      phase:      this.phase,
      question:   this.question,
      currentQ:   this.currentQ,
      totalQ:     this.questions.length,
      myVote:     this.votes[id] || null,
      voteCounts: this.phase === 'results' ? this._counts() : null,
      scores:     this.scores,
      players:    this.players,
    };
  }

  _counts() {
    const c = { A: 0, B: 0 };
    Object.values(this.votes).forEach(v => { if (v) c[v]++; });
    return c;
  }

  action(playerId, data) {
    if (this.finished) return { error: 'Game over.' };
    if (data.type === 'vote') {
      if (this.votes[playerId]) return { error: 'Already voted.' };
      if (!['A','B'].includes(data.choice)) return { error: 'Invalid choice.' };
      this.votes[playerId] = data.choice;
      if (Object.keys(this.votes).length >= this.players.length) {
        this.phase = 'results';
        const counts = this._counts();
        const majority = counts.A >= counts.B ? 'A' : 'B';
        this.players.forEach(p => {
          if (this.votes[p.id] === majority) this.scores[p.id]++;
        });
      }
      return { ok: true };
    }
    if (data.type === 'next') {
      this.currentQ++;
      this.votes = {};
      if (this.currentQ >= this.questions.length) {
        this.finished = true;
        const winner = Object.entries(this.scores).sort((a,b) => b[1]-a[1])[0][0];
        return { ok: true, finishResult: { winner } };
      }
      this.phase = 'vote';
      return { ok: true };
    }
    return { error: 'Unknown action.' };
  }
}

class TwoTruthsEngine {
  constructor(players) {
    this.players    = players;
    this.scores     = Object.fromEntries(players.map(p => [p.id, 0]));
    this.queue      = [...players];
    this.phase      = 'submit'; // submit | guess | reveal
    this.currentPresenter = null;
    this.statements = null;
    this.lieIdx     = null;
    this.guesses    = {};
    this.finished   = false;
    this._nextPresenter();
  }

  _nextPresenter() {
    if (this.queue.length === 0) return;
    this.currentPresenter = this.queue.shift();
    this.phase      = 'submit';
    this.statements = null;
    this.lieIdx     = null;
    this.guesses    = {};
  }

  stateFor(id) {
    return {
      phase:            this.phase,
      currentPresenter: this.currentPresenter,
      statements:       this.statements,
      lieIdx:           this.phase === 'reveal' ? this.lieIdx : null,
      guesses:          this.phase === 'reveal' ? this.guesses : {},
      myGuess:          this.guesses[id] ?? null,
      scores:           this.scores,
      players:          this.players,
    };
  }

  action(playerId, data) {
    if (this.finished) return { error: 'Game over.' };
    if (this.phase === 'submit') {
      if (playerId !== this.currentPresenter?.id) return { error: 'Wait your turn.' };
      if (data.type === 'submit') {
        if (!data.statements || data.statements.length !== 3) return { error: 'Need 3 statements.' };
        if (data.lieIdx == null) return { error: 'Mark the lie.' };
        this.statements = data.statements;
        this.lieIdx     = data.lieIdx;
        this.phase      = 'guess';
        return { ok: true };
      }
    }
    if (this.phase === 'guess') {
      if (playerId === this.currentPresenter?.id) return { error: "You're presenting!" };
      if (data.type === 'guess') {
        if (this.guesses[playerId] !== undefined) return { error: 'Already guessed.' };
        this.guesses[playerId] = data.guessIdx;
        const nonPresenters = this.players.filter(p => p.id !== this.currentPresenter.id);
        if (nonPresenters.every(p => this.guesses[p.id] !== undefined)) {
          this.phase = 'reveal';
          nonPresenters.forEach(p => {
            if (this.guesses[p.id] === this.lieIdx) this.scores[p.id]++;
            else this.scores[this.currentPresenter.id]++;
          });
        }
        return { ok: true };
      }
    }
    if (this.phase === 'reveal') {
      if (data.type === 'next') {
        if (this.queue.length === 0) {
          this.finished = true;
          const winner = Object.entries(this.scores).sort((a,b) => b[1]-a[1])[0][0];
          return { ok: true, finishResult: { winner } };
        }
        this._nextPresenter();
        return { ok: true };
      }
    }
    return { error: 'Unknown action.' };
  }
}

class NeverHaveIEverEngine {
  constructor(players) {
    this.players    = players;
    this.scores     = Object.fromEntries(players.map(p => [p.id, 0]));
    this.questions  = NHIE_QUESTIONS.sort(() => Math.random() - 0.5).slice(0, 8);
    this.currentQ   = 0;
    this.answers    = {};
    this.phase      = 'play';
    this.finished   = false;
  }

  get question() { return { text: this.questions[this.currentQ] }; }

  stateFor(id) {
    return {
      phase:    this.phase,
      question: this.question,
      currentQ: this.currentQ,
      totalQ:   this.questions.length,
      myAnswer: this.answers[id] ?? null,
      answers:  this.phase === 'reveal' ? this.answers : null,
      scores:   this.scores,
      players:  this.players,
    };
  }

  action(playerId, data) {
    if (this.finished) return { error: 'Game over.' };
    if (this.phase === 'play') {
      if (data.type === 'answer') {
        if (this.answers[playerId] !== undefined) return { error: 'Already answered.' };
        this.answers[playerId] = data.haveI;
        if (this.players.every(p => this.answers[p.id] !== undefined)) {
          // Score: each person who "have" gets 1 pt
          this.players.forEach(p => { if (this.answers[p.id]) this.scores[p.id]++; });
          this.phase = 'reveal';
        }
        return { ok: true };
      }
    }
    if (this.phase === 'reveal') {
      if (data.type === 'next') {
        this.currentQ++;
        this.answers = {};
        if (this.currentQ >= this.questions.length) {
          this.finished = true;
          const winner = Object.entries(this.scores).sort((a,b) => b[1]-a[1])[0][0];
          return { ok: true, finishResult: { winner } };
        }
        this.phase = 'play';
        return { ok: true };
      }
    }
    return { error: 'Unknown action.' };
  }
}

// ── Contexto ─────────────────────────────────────────────────────────────────
const CONTEXTO_WORDS = [
  ['OCEAN','WAVE','BEACH','SHARK','CORAL','TIDE','SAIL','COAST'],
  ['FOREST','TREE','LEAF','BARK','ROOT','BRANCH','PINE','OAK'],
  ['KITCHEN','SPOON','COOK','OVEN','RECIPE','DISH','FLOUR','HERB'],
  ['MUSIC','BEAT','DRUM','SONG','BAND','NOTE','TEMPO','CHORD'],
  ['SPACE','STAR','MOON','ORBIT','COMET','PLANET','ROCKET','VOID'],
];

function buildContextoRanks(words, answer) {
  const ranks = {};
  words.forEach((w, i) => { ranks[w] = i === 0 ? 0 : Math.floor(Math.random() * 998) + 1; });
  ranks[answer] = 0;
  return ranks;
}

class ContextoEngine {
  constructor(players) {
    this.players  = players;
    const set     = CONTEXTO_WORDS[Math.floor(Math.random() * CONTEXTO_WORDS.length)];
    this.answer   = set[0].toUpperCase();
    this.rankMap  = buildContextoRanks(set.map(w => w.toUpperCase()), this.answer);
    this.states   = {};
    this.finished = false;
    this.winner   = null;

    players.forEach(p => {
      this.states[p.id] = { guesses: [], solved: false, gaveUp: false };
    });
  }

  stateFor(id) {
    const s = this.states[id];
    return {
      guesses:  s.guesses,
      solved:   s.solved,
      gaveUp:   s.gaveUp,
      answer:   (s.solved || s.gaveUp) ? this.answer : undefined,
    };
  }

  _rank(word) {
    const w = word.toUpperCase();
    if (w === this.answer) return 0;
    if (this.rankMap[w] !== undefined) return this.rankMap[w];
    return Math.floor(Math.random() * 5000) + 500;
  }

  action(playerId, data) {
    if (this.finished) return { error: 'Game over.' };
    const s = this.states[playerId];
    if (!s) return { error: 'Not in game.' };

    if (data.type === 'guess') {
      const word  = (data.word || '').toUpperCase();
      if (!/^[A-Z]+$/.test(word)) return { error: 'Letters only.' };
      if (s.guesses.find(g => g.word === word)) return { error: 'Already guessed.' };
      const score = this._rank(word);
      s.guesses.push({ word, score });
      if (score === 0) {
        s.solved = true;
        if (!this.winner) {
          this.winner   = playerId;
          this.finished = true;
          return { ok: true, finishResult: { winner: this.winner, answer: this.answer } };
        }
      }
      return { ok: true };
    }

    if (data.type === 'giveUp') {
      s.gaveUp = true;
      const allDone = Object.values(this.states).every(st => st.solved || st.gaveUp);
      if (allDone) {
        this.finished = true;
        return { ok: true, finishResult: { winner: this.winner, answer: this.answer } };
      }
      return { ok: true };
    }

    return { error: 'Unknown action.' };
  }
}

// ─── Engine factory ──────────────────────────────────────────────────────────
function createEngine(gameId, players) {
  switch (gameId) {
    case 'wordle':      return new WordleEngine(players);
    case 'connections': return new ConnectionsEngine(players);
    case 'connect4':    return new Connect4Engine(players);
    case 'uno':         return new UnoEngine(players);
    case 'contexto':    return new ContextoEngine(players);
    case 'wyr':         return new WouldYouRatherEngine(players);
    case '2truths':     return new TwoTruthsEngine(players);
    case 'nhie':        return new NeverHaveIEverEngine(players);
    default:            return null;
  }
}

// ─── Socket.io handlers ───────────────────────────────────────────────────────
io.on('connection', (socket) => {

  socket.on('setName', ({ name }) => {
    const trimmed = (name || '').trim().slice(0, 16);
    if (!trimmed) return socket.emit('nameError', { message: 'Name required.' });
    players.set(socket.id, { id: socket.id, name: trimmed, roomCode: null });
    socket.emit('nameAccepted', { id: socket.id });
  });

  socket.on('getLobbyList', () => {
    const list = [...rooms.values()]
      .filter(r => !r.gameActive && r.players.length > 0)
      .map(r => ({ code: r.code, gameId: r.gameId, name: r.gameId, playerCount: r.players.length }));
    socket.emit('lobbyList', { rooms: list });
  });

  socket.on('createRoom', ({ gameId }) => {
    const player = players.get(socket.id);
    if (!player) return;
    const room = new Room(socket.id, gameId);
    room.addPlayer(player);
    rooms.set(room.code, room);
    player.roomCode = room.code;
    socket.join(room.code);
    socket.emit('roomJoined', { room: room.serialize() });
    room.broadcast('chatMessage', { system: true, message: `${player.name} created the room.` });
  });

  socket.on('joinRoom', ({ code }) => {
    const player = players.get(socket.id);
    if (!player) return;
    const room = rooms.get(code);
    if (!room) return socket.emit('roomError', { message: 'Room not found.' });
    if (room.gameActive) return socket.emit('roomError', { message: 'Game already in progress.' });
    room.addPlayer(player);
    player.roomCode = room.code;
    socket.join(room.code);
    socket.emit('roomJoined', { room: room.serialize() });
    room.broadcast('roomUpdated', { room: room.serialize() });
    room.broadcast('chatMessage', { system: true, message: `${player.name} joined.` });
  });

  socket.on('startGame', () => {
    const player = players.get(socket.id);
    if (!player || !player.roomCode) return;
    const room = rooms.get(player.roomCode);
    if (!room) return;
    if (room.hostId !== socket.id) return socket.emit('roomError', { message: 'Only the host can start.' });
    if (room.players.length < 1) return socket.emit('roomError', { message: 'Need at least 1 player.' });

    const engine = createEngine(room.gameId, room.players);
    if (!engine) return socket.emit('roomError', { message: 'Unknown game.' });
    room.gameEngine = engine;
    room.gameActive = true;

    room.players.forEach(p => {
      const pSocket = io.sockets.sockets.get(p.id);
      if (pSocket) {
        pSocket.emit('gameStarted', {
          gameId: room.gameId,
          state:  engine.stateFor(p.id),
        });
      }
    });
  });

  socket.on('gameAction', (data) => {
    const player = players.get(socket.id);
    if (!player || !player.roomCode) return;
    const room = rooms.get(player.roomCode);
    if (!room || !room.gameEngine) return;

    const result = room.gameEngine.action(socket.id, data);
    if (!result) return;

    if (result.error && !result.ok) {
      return socket.emit('gameError', { message: result.error });
    }

    // Broadcast updated state to all players
    room.players.forEach(p => {
      const pSocket = io.sockets.sockets.get(p.id);
      if (pSocket) pSocket.emit('gameState', { state: room.gameEngine.stateFor(p.id) });
    });

    if (result.finishResult) {
      room.gameActive = false;
      room.broadcast('gameFinished', { result: result.finishResult });
    }
  });

  socket.on('chatMessage', ({ message }) => {
    const player = players.get(socket.id);
    if (!player || !player.roomCode) return;
    const room = rooms.get(player.roomCode);
    if (!room) return;
    const safe = (message || '').trim().slice(0, 200);
    if (!safe) return;
    room.broadcast('chatMessage', { name: player.name, message: safe });
  });

  socket.on('leaveRoom', () => {
    handleLeave(socket);
  });

  socket.on('disconnect', () => {
    handleLeave(socket);
    players.delete(socket.id);
  });

  function handleLeave(sock) {
    const player = players.get(sock.id);
    if (!player || !player.roomCode) return;
    const room = rooms.get(player.roomCode);
    if (!room) return;
    room.removePlayer(sock.id);
    sock.leave(room.code);
    player.roomCode = null;
    if (room.players.length === 0) {
      rooms.delete(room.code);
    } else {
      room.broadcast('roomUpdated', { room: room.serialize() });
      room.broadcast('chatMessage', { system: true, message: `${player.name} left.` });
    }
  }
});

// ─── Start ───────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Goon Room running on port ${PORT}`);
});
